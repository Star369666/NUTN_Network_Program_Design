package com.example.s11059003_hw1;

import static java.lang.Math.round;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{
    Button b;
    TextView t1, t2, t3, t4;
    Spinner spin;
    EditText e1, e2;
    static double[] value = {3.3, 3.5, 3.2};
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b = (Button) findViewById(R.id.b1);
        t1 = (TextView) findViewById(R.id.input1);
        t2 = (TextView) findViewById(R.id.input2);
        t3 = (TextView) findViewById(R.id.show1);
        t4 = (TextView) findViewById(R.id.show2);
        e1 = (EditText) findViewById(R.id.e1);
        e2 = (EditText) findViewById(R.id.e2);
        spin = (Spinner) findViewById(R.id.spin);

        b.setOnClickListener(this::start);
        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                index = spin.getSelectedItemPosition();
                t3.setText("消耗能量(仟卡/公斤/小時)：" + value[index]);
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                index = spin.getSelectedItemPosition();
                t3.setText("消耗能量(仟卡/公斤/小時)：" + value[index]);
            }
        });
    }

    @SuppressLint("SetTextI18n")
    public void start(View v){
        if(v.getId() == R.id.b1){
            double weight = Double.parseDouble(e1.getText().toString());
            check(weight);
            double hour = Double.parseDouble(e2.getText().toString());
            check(hour);
            t4.setText("消耗能量" + round(weight*hour*value[index]) + "仟卡");
        }
    }

    public void check(double in){
        if(in <= 0){
            System.out.println("不接受等於或小於0的數值");
            System.exit(1);
        }
    }
}