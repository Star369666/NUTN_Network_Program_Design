/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tcpserver;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 *
 * @author USER
 */
public class TCPServer {
    private static ServerSocket socket;
    private static final int port = 1236;
    private static int matrix_row;
    private static int matrix_column;
    
    public static void main(String[] args){
        System.out.println("Opening port...\n");
        try {
            socket = new ServerSocket(port);
        }
        catch(IOException e) {
            System.out.println("Unable to attach to port!");
            System.exit(1);
        }
        do {
            handleClient();
        } while(true);
    }

    private static void handleClient() {
        Socket link = null;
        int i;
        try {
            link = socket.accept();
            Scanner input = new Scanner(link.getInputStream());
            PrintWriter output = new PrintWriter(link.getOutputStream(), true);
            
            while(input.hasNextBoolean()) {
                if (input.nextBoolean() == false) {
                    break;
                }
                
                matrix_row = input.nextInt();
                matrix_column = input.nextInt();
                int matrix_total = matrix_row*matrix_column;

                int[] first_matrix = new int[matrix_total];
                int[] second_matrix = new int[matrix_total];
                int[] sum = new int[matrix_total];
                
                input.nextLine();   //clean the return key from getting a boolean
                
                first_matrix = get_matrix_as_string(input.nextLine());
                second_matrix = get_matrix_as_string(input.nextLine());

                for(i = 0; i < first_matrix.length; i++) {
                    sum[i] = first_matrix[i] + second_matrix[i];
                }
                output.println(Arrays.toString(sum));
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                System.out.println("\n* Closing connection... *");
                if (link != null && !link.isClosed()) {
                    link.close();
                }
            }
            catch(IOException e) {
                System.out.println("Unable to disconnect!");
                System.exit(1);
            }
        }
    }
    
    private static int[] get_matrix_as_string(String get_string) {
        int i;
        String[] buffer = get_string.substring(1, get_string.length() - 1).split(", ");
        int[] result = new int[buffer.length];
        for(i = 0; i < buffer.length; i++) {
            result[i] = Integer.parseInt(buffer[i]);
        }
        return result;
    }
}
