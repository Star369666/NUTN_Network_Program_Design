/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tcpclient;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 *
 * @author USER
 */
public class TCPClient {
    private static InetAddress host;
    private static final int port = 1236;
    private static int matrix_row;
    private static int matrix_column;
    
    public static void main(String[] args) {
        try {
            host = InetAddress.getLocalHost();
        }
        catch(UnknownHostException e) {
            System.out.println("Host ID not found!");
            System.exit(1);
        }
        accessServer();
    }
    
    private static void accessServer() {
        Socket link = null;
        try {
            link = new Socket(host, port);
            Scanner input = new Scanner(link.getInputStream());
            PrintWriter output = new PrintWriter(link.getOutputStream(), true);
            boolean is_continue;
            
            while(true) {
                is_continue = make_start();
                output.println(is_continue);

                if(!is_continue) {
                    break;
                }
                
                matrix_row = get_correct_int("Matrix row", false, 0, 0, "row size(from 0 to n): ");
                matrix_column = get_correct_int("Matrix column", false, 0, 0, "column size(from 0 to m): ");

                String first_matrix, second_matrix;
                first_matrix = get_matrix_as_string("first");
                second_matrix = get_matrix_as_string("second");
                output.println(matrix_row);
                output.println(matrix_column);
                output.println(first_matrix);
                output.println(second_matrix); 

                if(input.hasNextLine()) {
                    print_sum_result(input.nextLine());
                }
                else {
                    System.out.println("Failed to get matrix from server!");
                }
            }
        }
        catch(IOException e) {
            System.out.println("Unable to disconnect!");
            System.exit(1);
        }
        finally {
            try {
                System.out.println("\n* Closing connection... *");
                if (link != null && !link.isClosed()) {
                    link.close();
                }
            }
            catch(IOException e) {
                System.out.println("Unable to disconnect!");
                System.exit(1);
            }
        }
    }
    
    private static boolean make_start() {
        System.out.println("Enter \"CLOSE\" to quit, or anything else to continue.");
        System.out.print("Note: Interruption during input is not allowed: ");
        Scanner user = new Scanner(System.in);
        String cancel = user.nextLine();
        return !cancel.equals("CLOSE");
    }
    
    private static String get_matrix_as_string(String order) {
        int i, j;

        System.out.println("Here is the example for the method to enter 2x2 matrix content one by one:");
        for(i = 0; i < 4; i++) {
            System.out.println("This is " + (i+1) + "/4 matrix content: " + (i+1));
        }
        System.out.println("first row: 1 2");
        System.out.println("second row: 3 4\n");
        
        System.out.println("This is the " + order + " matrix input.");
        int[] matrix = new int[matrix_row*matrix_column];
        for(i = 0; i < matrix_row; i++) {
            for(j = 0; j < matrix_column; j++) {
                matrix[matrix_column*i+j] = get_correct_int("The row = " + i + ", column = " + j + " matrix content",
                        true, matrix_column*i+j+1, matrix_row*matrix_column, "");
            }
        }
        System.out.println("");
        return Arrays.toString(matrix);
    }
    
    private static int get_correct_int(String object, boolean is_content, int order, int len, String size) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            if (is_content) {
                System.out.print("This is " + order + "/" + len + " matrix content: ");
            }
            else {
                System.out.print("Enter the matrix " + size);
            }
            
            if (sc.hasNextInt()) {
                return sc.nextInt();
            } 
            else {
                System.out.println(object + " is invalid! Need to be an integer!");
                sc.next();
            }
        }
    }
    
    private static void print_sum_result(String get_string) {
        int i, j;
        String[] buffer = get_string.substring(1, get_string.length() - 1).split(", ");
        int[] result = new int[buffer.length];
        
        System.out.println("The sum result is:");
        for(i = 0; i < matrix_row; i++) {
            System.out.print("The " + i + "th row: ");
            for(j = 0; j < matrix_column; j++) {
                if(j == matrix_column-1) {
                    System.out.print(Integer.parseInt(buffer[matrix_column*i+j]) + "\n");
                }
                else {
                    System.out.print(Integer.parseInt(buffer[matrix_column*i+j]) + ", ");
                }
            }
        }
        System.out.println("");
    }
}
