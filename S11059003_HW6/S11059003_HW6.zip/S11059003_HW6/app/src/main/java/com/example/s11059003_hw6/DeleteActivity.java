package com.example.s11059003_hw6;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteActivity extends AppCompatActivity {

    Bundle bundle;
    String[] arg;
    int len;
    Cursor res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        bundle = getIntent().getExtras();
        len = Constant.search_key_num;
        arg = new String[len];
        arg = Constant.get_intent_info(0, len, bundle);
        res = Constant.dbHelp.search(arg);
        Constant.bad_query(bundle, this, this, res, true);
    }

    public void show_information(View v) {
        res = Constant.dbHelp.search(arg);
        if(res != null && res.getCount() != 0) {
            StringBuilder buffer = Constant.List_database_result(res);
            Constant.showMessage(this, "Data", buffer.toString());
        }
    }

    public void delete(View v) {
        Constant.dbHelp.delete(arg);
        finish();
    }

    public void back(View v) {
        finish();
    }
}