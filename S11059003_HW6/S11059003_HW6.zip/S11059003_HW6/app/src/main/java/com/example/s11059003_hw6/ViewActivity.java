package com.example.s11059003_hw6;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
    }

    public void view_all(View v) {
        Cursor res = Constant.dbHelp.getAll();
        if(res != null && res.getCount() != 0) {
            StringBuilder buffer = Constant.List_database_result(res);
            Constant.showMessage(this, "Data", buffer.toString());
        }
        else {
            Constant.showMessage_finish(this, this,"錯誤", "搜尋目標是空的");
        }
    }

    public void back(View v) {
        finish();
    }
}