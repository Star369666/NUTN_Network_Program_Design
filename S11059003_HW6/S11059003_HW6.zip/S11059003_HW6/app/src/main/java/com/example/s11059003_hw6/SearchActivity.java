package com.example.s11059003_hw6;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {
    Bundle bundle;
    String[] element;
    int len;
    Cursor res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        bundle = getIntent().getExtras();
        len = Constant.search_key_num;
        element = new String[len];
        element = Constant.get_intent_info(0, len, bundle);
        res = Constant.dbHelp.search(element);
        Constant.bad_query(bundle, this, this, res, true);
    }

    public void search(View v) {
        if(res != null && res.getCount() != 0) {
            StringBuilder buffer = Constant.List_database_result(res);
            Constant.showMessage(this, "Data", buffer.toString());
        }
        else {
            Constant.showMessage_finish(this, this,"錯誤", "搜尋目標是空的");
        }
    }

    public void back(View v) {
        finish();
    }
}