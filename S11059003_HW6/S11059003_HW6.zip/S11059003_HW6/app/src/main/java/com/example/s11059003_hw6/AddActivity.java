package com.example.s11059003_hw6;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {
    Intent write_intent;
    Bundle bundle;
    String[] element;
    int len = Constant.table_column_num - 1;
    StringBuilder buffer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        write_intent = getIntent();
        bundle = write_intent.getExtras();
        element = new String[len];
        Constant.bad_query(bundle, this, this, null, false);
        buffer = new StringBuilder();
        get_information();
    }

    public void get_information() {
        int i;
        for(i = 0; i < len; i++) {
            String data = bundle.getString(Constant.title[i]);
            element[i] = data;
            buffer.append(Constant.title[i] + "：" + data + "\n");
        }
        buffer.append("\n是否正確?");
    }

    public void show_information(View v) {
        Constant.showMessage(this, "插入請求內容", buffer.toString());
    }

    public void insert(View v) {
        boolean is_inserted = Constant.dbHelp.insert(element);
        System.out.println(element[0] + "：" + element[1] + " inserted");
        if (is_inserted) {
            Log.d("Sqlite: ", "Data inserted");
        } else {
            Log.d("Sqlite: ", "Data not inserted");
        }
        finish();
    }

    public void back(View v) {
        finish();
    }
}