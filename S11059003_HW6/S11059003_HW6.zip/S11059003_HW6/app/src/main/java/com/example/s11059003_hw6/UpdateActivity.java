package com.example.s11059003_hw6;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

public class UpdateActivity extends AppCompatActivity {

    Bundle bundle;
    String[] arg, value;
    int len;
    Cursor res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        bundle = getIntent().getExtras();
        len = Constant.search_key_num;
        arg = new String[len];
        value = new String[len];
        arg = Constant.get_intent_info(0, len, bundle);
        value = Constant.get_intent_info(len, 2*len, bundle);
        res = Constant.dbHelp.search(arg);
        Constant.bad_query(bundle, this, this, res, true);
    }

    public void show_information(View v) {
        res = Constant.dbHelp.search(arg);
        if(res != null && res.getCount() != 0) {
            StringBuilder buffer = Constant.List_database_result(res);
            Constant.showMessage(this, "Data", buffer.toString());
        }
    }

    public void update(View v) {
        System.out.println("arg = " + arg[0] + "  " + arg[1] + ", value = " + value[0] + "  " + value[1]);
        Constant.dbHelp.update(arg, value);
        finish();
    }

    public void back(View v) {
        finish();
    }
}