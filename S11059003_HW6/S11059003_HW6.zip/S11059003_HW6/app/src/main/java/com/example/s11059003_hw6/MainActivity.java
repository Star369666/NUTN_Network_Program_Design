package com.example.s11059003_hw6;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText id, name, eng_score, py_score;
    Button but_add, but_delete, but_search, but_view, but_update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Constant.dbHelp = new DatabaseHelper(this);

        id = findViewById(R.id.edit1);
        name = findViewById(R.id.edit2);
        eng_score = findViewById(R.id.edit3);
        py_score = findViewById(R.id.edit4);
        but_add = findViewById(R.id.but_add);
        but_delete = findViewById(R.id.but_delete);
        but_update = findViewById(R.id.but_update);
        but_view = findViewById(R.id.but_view);
        but_search = findViewById(R.id.but_search);
        Insert();
        View_all();
        Search();
        Delete();
        Update();
    }

    public void Insert() {
        but_add.setOnClickListener(view -> {
            Intent intent = new Intent(this, AddActivity.class);
            int i;
            String[] info = get_editText(0);

            Constant.check_null = false;
            for(i = 0; i < info.length; i++) {
                if(info[i].isEmpty()) {
                    Constant.check_null = true;
                }
                intent.putExtra(Constant.title[i], info[i]);
            }
            intent.putExtra(Constant.check_null_index, Constant.check_null);

            clean_textView(id);
            clean_textView(name);
            clean_textView(eng_score);
            clean_textView(py_score);

            startActivity(intent);
        });
    }

    public void View_all() {
        but_view.setOnClickListener(view -> {
            Intent intent = new Intent(this, ViewActivity.class);
            startActivity(intent);
        });
    }

    public void Search() {
        but_search.setOnClickListener(view -> query_stuid_and_name(0, SearchActivity.class));
    }

    public void Delete() {
        but_delete.setOnClickListener(view -> query_stuid_and_name(0, DeleteActivity.class));
    }

    public void Update() {
        but_update.setOnClickListener(view -> query_stuid_and_name(1, UpdateActivity.class));
    }

    public String[] get_editText(int mode) {
        String[] temp = new String[Constant.table_column_num-1];
        temp[0] = id.getText().toString();
        temp[1] = name.getText().toString();
        temp[2] = eng_score.getText().toString();
        temp[3] = py_score.getText().toString();

        int i;
        for(i = 0; i < temp.length * (int)Math.pow(2, mode) / 2; i += 2) {
            Constant.check_null = temp[i].isEmpty() && temp[i + 1].isEmpty();
            if(Constant.check_null) {
                break;
            }
        }

        clean_textView(id);
        clean_textView(name);
        clean_textView(eng_score);
        clean_textView(py_score);

        return temp;
    }

    public void clean_textView(EditText t) {
        t.setText("");
    }

    public void query_stuid_and_name(int mode, Class<?> activityClass) {
        int i;
        String[] element = get_editText(mode);
        Intent intent = new Intent(this, activityClass);

        if(mode == 1) {
            for(i = 0; i < Constant.title.length; i++) {
                intent.putExtra(Constant.title[i], element[i]);
            }
        }
        else {
            for(i = 0; i < Constant.search_key_num; i++) {
                intent.putExtra(Constant.title[i], element[i]);
            }
        }
        intent.putExtra(Constant.check_null_index, Constant.check_null);

        startActivity(intent);
    }
}
