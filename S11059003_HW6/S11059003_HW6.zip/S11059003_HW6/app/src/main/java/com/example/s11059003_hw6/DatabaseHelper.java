package com.example.s11059003_hw6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "star.db";
    public static final String TABLE_NAME = "student_table";
    public static final String[] COL = {"STUID", "NAME", "ENGLISH_SCORE", "PYTHON_SCORE"};
    public SQLiteDatabase db;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
        db = this.getWritableDatabase();
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, STUID TEXT, " +
                   "NAME TEXT, ENGLISH_SCORE TEXT, PYTHON_SCORE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int old_version, int new_version) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insert(String[] element) {
        int i;
        ContentValues contentValues = new ContentValues();
        for(i = 0; i < COL.length; i++) {
            contentValues.put(COL[i], element[i]);
        }
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public Cursor getAll() {
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME, null);
        if(cursor != null && cursor.getCount() > 0) {
            return cursor;
        } else {
            return null;
        }
    }

    public Cursor search(String[] arg) {
        String query = "select ID, " +
                        COL[0] + ", " +
                        COL[1] + ", " +
                        COL[2] + ", " +
                        COL[3] + " from " + TABLE_NAME + " where ";
        if(arg[1].isEmpty()) {
            return db.rawQuery(query + COL[0] + " = ?", new String[] {arg[0]});
        }
        else if(arg[0].isEmpty()) {
            return db.rawQuery(query + COL[1] + " = ?", new String[] {arg[1]});
        }
        else {
            return db.rawQuery(query + COL[0] + " = ? and " + COL[1] + " = ?", arg);
        }
    }

    public void delete(String[] arg) {
        if(arg[1].isEmpty()) {
            db.delete(TABLE_NAME, COL[0] + " = ?", new String[] {arg[0]});
        }
        else if(arg[0].isEmpty()) {
            db.delete(TABLE_NAME, COL[1] + " = ?", new String[] {arg[1]});
        }
        else {
            db.delete(TABLE_NAME, COL[0] + " = ? and " + COL[1] + " = ?", arg);
        }
    }

    public void update(String[] arg, String[] value) {
        ContentValues contentValues = new ContentValues();
        if(value[1].isEmpty()) {
            contentValues.put(COL[2], value[0]);
        }
        else if(value[0].isEmpty()) {
            contentValues.put(COL[3], value[1]);
        }
        else {
            contentValues.put(COL[2], value[0]);
            contentValues.put(COL[3], value[1]);
        }

        if(arg[1].isEmpty()) {
            db.update(TABLE_NAME, contentValues, COL[0] + " = ?", new String[] {arg[0]});
        }
        else if(arg[0].isEmpty()) {
            db.update(TABLE_NAME, contentValues, COL[1] + " = ?", new String[] {arg[1]});
        }
        else {
            db.update(TABLE_NAME, contentValues, COL[0] + " = ? and " + COL[1] + " = ?", arg);
        }
    }
}

