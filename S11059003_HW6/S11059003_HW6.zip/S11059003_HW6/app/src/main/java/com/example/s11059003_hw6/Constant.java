package com.example.s11059003_hw6;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

public class Constant {
    public static DatabaseHelper dbHelp;
    public final static String[] title = {"id", "name", "eng_score", "py_score"};
    public final static int table_column_num = 5;
    public final static int search_key_num = 2;
    public static Boolean check_null;
    public final static String check_null_index = "check_null";

    public static String[] get_intent_info(int start, int end, Bundle bundle) {
        int i;
        String[] element = new String[end-start];
        for(i = start; i < end; i++) {
            String temp = bundle.getString(Constant.title[i]);
            element[i-start] = temp;
        }
        return element;
    }

    public static void showMessage(Context context, String title, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        ScrollView scrollView = new ScrollView(context);
        TextView textView = new TextView(context);
        scrollView.addView(textView);
        builder.setView(scrollView);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }

    public static void showMessage_finish(Activity act, Context context, String title, String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        ScrollView scrollView = new ScrollView(context);
        TextView textView = new TextView(context);
        scrollView.addView(textView);
        builder.setView(scrollView);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        AlertDialog dialog = builder.create();
        dialog.setOnDismissListener(dialogInterface -> act.finish());
        dialog.show();
    }

    public static StringBuilder List_database_result(Cursor res) {
        StringBuilder buffer = new StringBuilder();
        while(res.moveToNext()) {
            buffer.append("ID：").append(res.getString(0)).append("\n");
            buffer.append("Stuid：").append(res.getString(1)).append("\n");
            buffer.append("Name：").append(res.getString(2)).append("\n");
            buffer.append("English_score：").append(res.getString(3)).append("\n");
            buffer.append("Python_score：").append(res.getString(4)).append("\n");
        }
        return buffer;
    }

    public static void bad_query(Bundle bundle, Activity act, Context context, Cursor cursor, Boolean mode) {
        if(bundle.getBoolean(Constant.check_null_index)) {
            Constant.showMessage_finish(act, context,"錯誤", "搜尋索引有缺失");
            return;
        }
        if(mode) {
            if(!(cursor != null && cursor.getCount() != 0)) {
                Constant.showMessage_finish(act, context,"錯誤", "搜尋目標是空的");
                return;
            }
        }
    }
}