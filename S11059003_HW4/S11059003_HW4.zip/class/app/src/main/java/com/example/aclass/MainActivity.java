package com.example.aclass;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {

    private TextView t;
    private EditText e;
    private StringBuffer dataString;
    private UIHandler uiHandler;
    private final static String[] element = {"ID", "Name", "Address", "Tel",  "HostWords", "Price", "OpenHours", "CreditCard",
            "TravelCard", "TrafficGuidelines", "ParkingLot", "Url", "Email", "PetNotice", "Reminder", "FoodMonths",
            "FoodCapacity", "FoodFeature", "City", "Town", "PicURL", "Latitude", "Longitude", "BlogUrl"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = findViewById(R.id.text);
        e = findViewById(R.id.edit);
        uiHandler = new UIHandler();
    }

    @SuppressLint("HandlerLeak")
    public class UIHandler extends Handler {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (msg.what == 0) {
                t.setText(dataString);
            }
        }
    }

    public void error_city(String city) {
        if(city.trim().length() <= 1 || city.trim().length() > 3) {
            System.err.println("無效的城市選擇");
            System.exit(1);
        }
    }

    public void download(View v) {
        dataString = new StringBuffer();
        String city = e.getText().toString();
        error_city(city);

        new Thread(() -> {
            try {
                URL url = new URL("https://data.moa.gov.tw/Service/OpenData/ODwsv/ODwsvTravelFood.aspx?&UnitId=193");
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.connect();
                BufferedReader read = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));
                String line;
                StringBuffer temp = new StringBuffer();
                while((line = read.readLine()) != null) {
                    temp.append(line);
                }
                read.close();
                parserJSON(temp.toString(), city);
            }
            catch (Exception e) {
                Log.v("download", e.toString());
            }
        }).start();
    }

    public void parserJSON(String js, String city) {
        int i, j;
        try {
            JSONArray root = new JSONArray(js);
            for(i = 0; i < root.length(); i++) {
                JSONObject row = root.getJSONObject(i);
                String compare_city = row.getString("City");

                if(compare_city.substring(0, 2).equals(city.substring(0, 2))) {
                    for(j = 0; j < element.length; j++) {
                        String temp = row.getString(element[j]);

                        if(temp.equals("")) {
                            temp = "無";
                        }

                        dataString.append(element[j] + "：" + temp + "\n");
                    }
                    dataString.append("--------------------------------------------------------------------" +
                            "------------------------------\n");
                }
            }
        }
        catch (Exception e) {
            Log.v("download", e.toString());
        }
        uiHandler.sendEmptyMessage(0);
    }
}