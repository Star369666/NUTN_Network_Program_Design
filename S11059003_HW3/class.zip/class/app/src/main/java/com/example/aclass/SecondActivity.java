package com.example.aclass;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SecondActivity extends AppCompatActivity {

    private final String file_name = "test_file.txt";
    TextView t;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        t = findViewById(R.id.textView);
        b = findViewById(R.id.button);
        t.setMovementMethod(new ScrollingMovementMethod());
        FileInputStream in = null;
        StringBuilder sb = new StringBuilder();

        try {
            in = openFileInput(file_name);

            int read = 0;
            while((read = in.read()) != -1) {
                sb.append((char) read);
            }
            t.setText(sb.toString());
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(in != null) {
                try {
                    in.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void back(View v) {
        finish();
    }
}