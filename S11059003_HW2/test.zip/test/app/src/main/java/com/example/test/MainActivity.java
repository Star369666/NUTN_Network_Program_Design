package com.example.test;

import static java.lang.Integer.parseInt;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("StaticFieldLeak")
    Button b1;
    EditText e1, e2;
    public static CAL object;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.but);
        e1 = findViewById(R.id.up);
        e2 = findViewById(R.id.down);
        object = new CAL();
    }

    public void switch_to_act2(View v) {
        if(isEmpty(e1.getText().toString()) || isEmpty(e2.getText().toString())) {
            System.err.println("No input available!");
            System.exit(1);
        }
        else {
            object.setFirst(parseInt(e1.getText().toString()));
            object.setSecond(parseInt(e2.getText().toString()));
            object.setGcd(object.GCD(object.getFirst(), object.getSecond()));
            Intent it = new Intent(this, SecondActivity.class);
            startActivity(it);
        }
    }

    public void update() {
        e1.setText("");
        e2.setText("");
    }

    public boolean isEmpty(String str) {
        return str.trim().length() <= 0;
    }

    public class CAL {
        private int first, second, gcd;

        CAL() {}

        protected void setFirst(int first) {
            this.first = first;
        }

        protected void setSecond(int second) {
            this.second = second;
        }

        protected void setGcd(int gcd) {
            this.gcd = gcd;
        }

        protected int getFirst() {
            return first;
        }

        protected int getSecond() {
            return second;
        }

        protected int getGcd() {
            return gcd;
        }

        public int GCD(int a, int b) {
            int max = Math.max(a, b);
            int min = a + b - max;
            if(min == 0){
                return max;
            }
            else{
                return GCD(min,max % min);
            }
        }

        public void reset() {
            update();
        }
    }
}