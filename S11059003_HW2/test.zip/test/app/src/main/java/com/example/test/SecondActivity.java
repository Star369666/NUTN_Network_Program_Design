package com.example.test;

import static com.example.test.MainActivity.object;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    Button b1;
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        b1 = findViewById(R.id.button);
        t1 = findViewById(R.id.textView2);
        update_view();
    }

    @SuppressLint("SetTextI18n")
    public void update_view() {
        t1.setText("LCM="+object.getFirst() * object.getSecond() / object.getGcd());
    }

    public void back_to_act1(View v) {
        object.reset();
        finish();
    }
}