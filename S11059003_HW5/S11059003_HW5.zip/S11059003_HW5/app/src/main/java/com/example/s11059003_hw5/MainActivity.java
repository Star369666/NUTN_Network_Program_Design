package com.example.s11059003_hw5;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    private EditText e;
    private String url;
    private final static String file_name = "out.csv";
    private final static String file_type = "csv\n";
    private final static int column = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e = findViewById(R.id.edit);
    }

    public void response(View v) {
        url = e.getText().toString().trim();
        String check_csv = url.substring(Math.max(0, url.length()-3));
        if(url.trim().length() < 4 || check_csv.equals(file_type)) {
            System.err.println("無效的csv輸入或無法下載");
            System.exit(1);
        }

        sendAndRequestResponse();
    }

    private void sendAndRequestResponse() {
        RequestQueue mRequest = Volley.newRequestQueue(this);
        StringRequest mString = new StringRequest(Request.Method.GET, url, response -> {
            try {
                File file = getBaseContext().getFileStreamPath(file_name);
                if (file.exists()) {
                    file.delete();
                }

                FileOutputStream out = openFileOutput(file_name, Context.MODE_APPEND);
                out.write(response.getBytes(StandardCharsets.UTF_8));
                out.close();
                parsing_csvFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }, error -> {
        });

        mRequest.add(mString);
    }

    @SuppressLint("SetTextI18n")
    private void parsing_csvFile() {
        try {
            int i;
            File file = getBaseContext().getFileStreamPath(file_name);
            FileInputStream instream = new FileInputStream(file);
            DataInputStream dstream = new DataInputStream(instream);
            BufferedReader br = new BufferedReader(new InputStreamReader(dstream));
            String line = br.readLine();
            String split = ",";
            TableLayout table = findViewById(R.id.table);
            Vector<Vector<String>> temp = new Vector<>();

            while ((line = br.readLine()) != null) {
                Vector<String> helper = new Vector<>();
                Collections.addAll(helper, line.split(split));
                temp.add(helper);
            }

            temp.sort(Comparator.comparingInt(a -> Integer.parseInt(a.get(9))));

            TableRow title1 = create_table_row();
            TableRow title2 = create_table_row();
            table_row_add_text("No.", title1);
            table_row_add_text("Address", title1);
            table_row_add_text("Type", title2);
            table_row_add_text("Price", title2);
            table.addView(title1);
            table.addView(title2);

            for (i = 0; i < column; i++) {
                Vector<String> apartment = temp.get(i);
                TableRow new_table1 = create_table_row();
                TableRow new_table2 = create_table_row();
                TableRow new_table3 = create_table_row();

                table_row_add_text(String.valueOf((i + 1)), new_table1);
                table_row_add_text(apartment.get(0) + "," + apartment.get(1) + "," + apartment.get(2)
                        + "," + apartment.get(3), new_table1);

                table_row_add_text(apartment.get(4) + "bed," + apartment.get(5) + "bath," + apartment.get(6)
                        + "sqft", new_table2);
                table_row_add_text(apartment.get(9), new_table2);

                table_row_add_text(" ", new_table3);

                table.addView(new_table1);
                table.addView(new_table2);
                table.addView(new_table3);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public TableRow create_table_row() {
        TableRow new_row = new TableRow(this);
        new_row.setOrientation((TableRow.HORIZONTAL));
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        new_row.setLayoutParams(params);
        return new_row;
    }

    public void table_row_add_text(String content, TableRow row) {
        TextView text = new TextView(this);
        text.setText(content);
        row.addView(text);
    }
}