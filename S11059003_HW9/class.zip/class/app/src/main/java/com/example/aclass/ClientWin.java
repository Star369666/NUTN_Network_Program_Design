package com.example.aclass;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ClientWin extends AppCompatActivity {
    private final int port = 2345;
    private String host;
    private Button[][] buttons = new Button[6][4];
    private TextView t1;
    String store, current;
    double first = 0;
    double second = 0;
    int operator = 0;
    boolean is_second = false;
    boolean is_dot = false;
    int dot = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_win);

        Intent intent = getIntent();
        this.host = intent.getStringExtra("Host");

        t1 = findViewById(R.id.text1);
        initialize_buttons();
    }

    public void b11_act(View v) {
        if (Double.isNaN(first)) {
            clean();
        }
        else {
            singal(first * second / 100);
        }
    }

    public void b12_act(View v) {
        clean();
        t1.setText(0);
    }

    public void b13_act(View v) {
        if(!Double.isNaN(first) || second == 0) {
            clean();
        }
        else {
            second = 0;
            t1.setText(0);
        }
    }

    public void b14_act(View v) {
        if(get_int(store) || store.isEmpty()) {
            clean();
        }
        else {
            String temp = String.valueOf(current);
            if (temp.contains(".")) {
                int index = temp.indexOf(".");
                if (temp.length() - index > 2) {
                     current = temp.substring(0, temp.length() - 1);
                }
            } else {
                current = temp.substring(0, temp.length() - 1);
            }
        }
        t1.setText(current);
        clean();
    }

    public void b21_act(View v) {
        singal(1 / first);
    }

    public void b22_act(View v) {
        singal(Math.pow(first, 2));
    }

    public void b23_act(View v) {
        singal(Math.sqrt(first));
    }

    public void b24_act(View v) {
        operator = 1;
    }

    public void b31_act(View v) {
        set_int(7);
    }

    public void b32_act(View v) {
        set_int(8);
    }

    public void b33_act(View v) {
        set_int(9);
    }

    public void b34_act(View v) {
        operator = 2;
    }

    public void b41_act(View v) {
        set_int(4);
    }

    public void b42_act(View v) {
        set_int(5);
    }

    public void b43_act(View v) {
        set_int(6);
    }

    public void b44_act(View v) {
        operator = 3;
    }

    public void b51_act(View v) {
        set_int(1);
    }

    public void b52_act(View v) {
        set_int(2);
    }

    public void b53_act(View v) {
        set_int(3);
    }

    public void b54_act(View v) {
        operator = 4;
    }

    public void b61_act(View v) {
        if(is_second) {
            second *= -1;
        }
        else {
            first *= -1;
        }
    }

    public void b62_act(View v) {
        set_int(0);
    }

    public void b63_act(View v) {
        if (!is_dot) {
            is_dot = true;
            dot = 0;
        }
    }

    public void b64_act(View v) {
        switch (operator) {
            case 1:
                singal(first / second);
                break;
            case 2:
                singal(first * second);
                break;
            case 3:
                singal(first - second);
                break;
            case 4:
                singal(first + second);
                break;
            default:
                clean();
                break;
        }
    }

    private boolean get_int(String temp) {
        return temp.trim().matches("-?\\d+");
    }

    private void clean() {
        t1.setText(0);
        first = 0;
        second = 0;
        is_second = false;
        is_dot = false;
        dot = 0;
        operator = 0;
    }

    private void set_int(int value) {
        if(first == 0 && second == 0) {
            clean();
        }

        if (is_second) {
            if (is_dot) {
                second += value * Math.pow(10, --dot);
            }
            else {
                second = second * 10 + value;
            }
            t1.setText(String.valueOf(second));
        }
        else {
            if (is_dot) {
                first += value * Math.pow(10, --dot);
            }
            else {
                first = first * 10 + value;
            }
        }
    }

    private void singal(double value) {
        t1.setText(String.valueOf(value));
    }

    private void initialize_buttons() {
        int i, j;
        int[] id = {R.id.b11, R.id.b12, R.id.b13, R.id.b14, R.id.b21, R.id.b22, R.id.b23, R.id.b24,
                R.id.b31, R.id.b32, R.id.b33, R.id.b34, R.id.b41, R.id.b42, R.id.b43, R.id.b44,
                R.id.b51, R.id.b52, R.id.b53, R.id.b54, R.id.b61, R.id.b62, R.id.b63, R.id.b64};
        for (i = 0; i < 6; i++) {
            for(j = 0; j < 4; j++) {
                buttons[i][j] = findViewById(id[4*i + j]);
            }
        }
    }

    @Override
    protected void onDestroy() {
        finish();
        super.onDestroy();
    }
}