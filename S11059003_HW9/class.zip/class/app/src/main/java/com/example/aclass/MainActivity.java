package com.example.aclass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText e;
    private Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e = findViewById(R.id.e);
        b = findViewById(R.id.b);
    }

    public void openClientWin(View v) {
        Intent intent = new Intent(this, ClientWin.class);

        String temp = e.getText().toString();
        if(!temp.isEmpty()) {
            e.setText("");
            intent.putExtra("Host", temp);
            startActivity(intent);
        }
    }
}