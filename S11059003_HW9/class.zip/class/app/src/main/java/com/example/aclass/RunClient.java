package com.example.aclass;

import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RunClient extends Thread {
    ClientWin window;
    int port;
    String hostname;

    final BlockingQueue<String> queue = new LinkedBlockingQueue<>();

    public BufferedReader reader;
    public PrintWriter writer;
    public Boolean loop;

    public RunClient(ClientWin win, String host, int port) {
        this.window = win;
        this.hostname = host;
        this.port = port;
    }

    public void run() {
        EditText e = window.findViewById(R.id.e);

        String res;
        try {
            Socket socket = new Socket(hostname, port);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
            loop = true;

            while (loop) {
                try {
                    writer.println(queue.take());
                }
                catch (InterruptedException exception) {}

                res = reader.readLine();
                res.trim();
                final String resp = res;
                window.runOnUiThread(() -> {
                    e.setText("");
                });
            }
            socket.close();
        }
        catch (IOException exception) {
            Logger.getLogger(RunClient.class.getName()).log(Level.SEVERE, null, exception);
            window.finish();
        }
    }

    public void write(String m) {
        queue.offer(m);
    }
}

