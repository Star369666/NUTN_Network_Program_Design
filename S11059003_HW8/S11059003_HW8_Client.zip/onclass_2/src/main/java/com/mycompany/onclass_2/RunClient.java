/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onclass_2;
import java.io.*;
import java.net.*;
import java.util.logging.*;
import java.util.*;
/**
 *
 * @author USER
 */
public class RunClient extends Thread {
    static ClientWin  window;
    int port;
    String hostname;
    public BufferedReader reader;
    public PrintWriter writer;
    public Boolean loop;
    
    public RunClient(ClientWin win, String host, int port) {
        this.window = win;
        this.port = port;
        this.hostname = host;
    }
    
    public void run() {
        String res;
        int i;
        try {
            Socket socket = new Socket(hostname, port);
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
            loop = true;
            writer.println(window.id);
            while(loop) {
                print_result(reader.readLine());
                window.size = new int[4];
                window.first = new ArrayList<>();
                window.second = new ArrayList<>();
                for(i = 0; i < 2; i++) {
                    window.element_count[i] = 0;
                    window.element_done[i] = false;
                }
                window.plus.setEnabled(true);
                window.multiply.setEnabled(true);
            }
            window.plus.setEnabled(false);
            window.multiply.setEnabled(false);
            window.confirm.setEnabled(false);
            socket.close();
            window.out.append("Client id = " + window.id + ", Client disconnected.\n");
        }
        catch(IOException e) {
            Logger.getLogger(RunClient.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static void print_result(String get_string) {
        int i, j;
        String[] buffer = get_string.substring(1, get_string.length() - 1).split(", ");
        int matrix_row = window.size[0];
        int matrix_column = window.size[3];
        
        window.out.append("\nThe result is:\n");
        for(i = 0; i < matrix_row; i++) {
            window.out.append("The " + i + "th row: ");
            for(j = 0; j < matrix_column; j++) {
                if(j == matrix_column-1) {
                    window.out.append(Integer.valueOf(buffer[matrix_column*i+j]) + "\n");
                }
                else {
                    window.out.append(Integer.valueOf(buffer[matrix_column*i+j]) + ", ");
                }
            }
        }
        window.out.append("\n");
    }
}
