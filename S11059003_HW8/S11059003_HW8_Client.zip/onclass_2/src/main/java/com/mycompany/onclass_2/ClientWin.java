/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.onclass_2;
import java.util.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USER
 */
public class ClientWin extends javax.swing.JFrame {
    private RunClient client;
    private ClientWin window;
    private final int port = 2345;
    private String host;
    private boolean able_plus = false;
    private boolean able_multiply = false;
    public static int[] size = new int[4];
    public static ArrayList<Integer> first = new ArrayList<>();
    public static ArrayList<Integer> second = new ArrayList<>();
    public static int[] element_count = {0, 0};
    public static boolean[] element_done = {false, false};
    public static long id;
    /**
     * Creates new form ClientWin
     */
    public ClientWin() {
        initComponents();
        this.window = this;
        host = "127.0.0.1";
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        connect = new javax.swing.JToggleButton();
        row1 = new java.awt.TextField();
        rowt1 = new java.awt.Label();
        colt1 = new java.awt.Label();
        col1 = new java.awt.TextField();
        colt2 = new java.awt.Label();
        rowt2 = new java.awt.Label();
        col2 = new java.awt.TextField();
        row2 = new java.awt.TextField();
        A = new java.awt.Label();
        in2 = new java.awt.TextField();
        B = new java.awt.Label();
        in1 = new java.awt.TextField();
        C = new java.awt.Label();
        out = new java.awt.TextArea();
        confirm = new javax.swing.JButton();
        multiply = new javax.swing.JToggleButton();
        plus = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        connect.setText("connect");
        connect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                connectActionPerformed(evt);
            }
        });

        rowt1.setText("First matrix row");

        colt1.setText("First matrix column");

        colt2.setText("Second matrix column");

        rowt2.setText("Second matrix row");

        A.setText("A");

        B.setText("B");

        C.setText("C");

        confirm.setText("Confirm");
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });

        multiply.setText("*");
        multiply.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                multiplyActionPerformed(evt);
            }
        });

        plus.setText("+");
        plus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                plusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rowt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(row1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(colt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(col1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rowt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(colt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(row2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(col2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(B, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(C, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(out, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(in2, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(plus, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(multiply, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(confirm, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(connect, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(A, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(in1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(17, 17, 17))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rowt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(row1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(row2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rowt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(colt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(col1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(colt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(col2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(A, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(in1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(B, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(76, 76, 76)
                        .addComponent(C, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(in2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(out, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(connect, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirm, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(multiply, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(plus, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void connectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_connectActionPerformed
        // TODO add your handling code here:
        connect.setEnabled(false);
        try {
            Thread.sleep(1000);
            id = System.currentTimeMillis();
        } catch (InterruptedException ex) {
            Logger.getLogger(ClientWin.class.getName()).log(Level.SEVERE, null, ex);
        }
        client = new RunClient(window, host, port);
        client.start();
    }//GEN-LAST:event_connectActionPerformed

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        // TODO add your handling code here:
        if(in1.getText().equals("CLOSE") || in2.getText().equals("CLOSE")) {
            confirm.setEnabled(false);
        }
        else {
            if(able_plus == true || able_multiply == true) {
                if(in1.getText().isEmpty() && in2.getText().isEmpty()) {
                    out.append("No input matrix content!\n");
                }
                else if(in1.getText().isEmpty() && element_count[1] < size[2]*size[3]) {
                    out.append("This is " + (element_count[1]+1) + "/" + size[2]*size[3] + " matrix content in second matrix.\n");
                    if(get_int(in2.getText())) {
                        out.append("Matrix content is accepted.\n");
                        second.add(Integer.valueOf(in2.getText()));
                        element_count[1]++;
                    }
                    else {
                        out.append("Matrix content is invalid!\n");
                    }
                }
                else if(in2.getText().isEmpty() && element_count[0] < size[0]*size[1]) {
                    out.append("This is " + (element_count[0]+1) + "/" + size[0]*size[1] + " matrix content in first matrix.\n");
                    if(get_int(in1.getText())) {
                        out.append("Matrix content is accepted.\n");
                        first.add(Integer.valueOf(in1.getText()));
                        element_count[0]++;
                    }
                    else {
                        out.append("Matrix content is invalid!\n");
                    }
                }

                in1.setText("");
                in2.setText("");

                if(element_count[0] == size[0]*size[1] && element_count[1] == size[2]*size[3]) {
                    plus.setEnabled(true);
                    multiply.setEnabled(true);
                }
                if(element_count[0] == size[0]*size[1] && element_done[0] == false) {
                    client.writer.println(id);
                    client.writer.println(0);
                    client.writer.println(send_matrix(0));
                    element_done[0] = true;
                }
                if(element_count[1] == size[2]*size[3] && element_done[1] == false) {
                    client.writer.println(id);
                    client.writer.println(1);
                    client.writer.println(send_matrix(1));
                    element_done[1] = true;
                }
            }
            else {
                if(plus.isEnabled() || multiply.isEnabled() && size != null) {
                    out.append("Not finished to choose a method yet!\n");
                }
            }
        }
    }//GEN-LAST:event_confirmActionPerformed

    private void plusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plusActionPerformed
        // TODO add your handling code here:
        client.writer.println(id);
        if(in1.getText().equals("CLOSE") || in2.getText().equals("CLOSE")) {
            client.writer.println(2);
            client.loop = false;
            client.interrupt();
        }
        else {
            client.writer.println(0);
            plus.setEnabled(false);
            client.writer.println(id);
            client.writer.println(0);
            String[] temp = get_matrix_size();
            int i;

            if(able_plus == true) {
                int[] size = new int[4];
                for(i = 0; i < 4; i++) {
                    size[i] = Integer.parseInt(temp[i]);
                }
                this.size = size;
                client.writer.println(id);
                client.writer.println(Arrays.toString(size));
            }
            else {
                if(confirm.isEnabled()) {
                    plus.setEnabled(true);
                    out.append("Matrix plus operation is invalid!\n");
                }
            }
        }
    }//GEN-LAST:event_plusActionPerformed

    private void multiplyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_multiplyActionPerformed
        // TODO add your handling code here:
        client.writer.println(id);
        if(in1.getText().equals("CLOSE") || in2.getText().equals("CLOSE")) {
            client.writer.println(2);
            client.loop = false;
            client.interrupt();
        }
        else {
            client.writer.println(0);
            multiply.setEnabled(false);
            client.writer.println(id);
            client.writer.println(1);
            String[] temp = get_matrix_size();
            int i;

            if(able_multiply == true) {
                int[] size = new int[4];
                for(i = 0; i < 4; i++) {
                    size[i] = Integer.parseInt(temp[i]);
                }
                this.size = size;
                client.writer.println(id);
                client.writer.println(Arrays.toString(size));
            }
            else {
                if(confirm.isEnabled()) {
                    multiply.setEnabled(true);
                    out.append("Matrix multiply operation is invalid!\n");
                }
            }
        } 
    }//GEN-LAST:event_multiplyActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientWin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientWin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientWin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientWin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientWin().setVisible(true);
            }
        });
    }
    
    private String[] get_matrix_size() {
        String[] size = new String[4];
        boolean is_all_size_good = true;
        able_plus = false;
        able_multiply = false;
        
        is_all_size_good = get_size(row1, "First matrix row");
        is_all_size_good = get_size(col1, "First matrix column");
        is_all_size_good = get_size(row2, "Second matrix row");
        is_all_size_good = get_size(col2, "Second matrix column");
        client.writer.println(is_all_size_good);
        
        if(is_all_size_good) {
            size[0] = row1.getText();
            size[1] = col1.getText();
            size[2] = row2.getText();
            size[3] = col2.getText();
            
            if(size[0].equals(size[2]) && size[1].equals(size[3])) {
                able_plus = true;
            }
            if(size[0].equals(size[3]) && size[1].equals(size[2])) {
                able_multiply = true;
            }
            clean_size_button();
            return size;
        }
        clean_size_button();
        return null;
    }
    
    private boolean get_size(TextField t, String object) {
        if(!get_int(t.getText())) {
            out.append(object + " is invalid!\n");
            return false;
        }
        return true;
    }
    
    private boolean get_int(String temp) {
        if(temp.matches("-?\\d+")) {
            return true;
        }
        return false;
    }
    
    private void clean_size_button() {
        row1.setText("");
        row2.setText("");
        col1.setText("");
        col2.setText("");
    }
    
    private String send_matrix(int order) {
        int i;
        int[] temp;
        
        if(order == 0) {
            temp = new int[first.size()];
            for(i = 0; i < first.size(); i++) {
                temp[i] = first.get(i);
            }
        }
        else {
            temp = new int[second.size()];
            for(i = 0; i < second.size(); i++) {
                temp[i] = second.get(i);
            }
        }
        return Arrays.toString(temp);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Label A;
    private java.awt.Label B;
    private java.awt.Label C;
    private java.awt.TextField col1;
    private java.awt.TextField col2;
    private java.awt.Label colt1;
    private java.awt.Label colt2;
    public javax.swing.JButton confirm;
    private javax.swing.JToggleButton connect;
    private java.awt.TextField in1;
    private java.awt.TextField in2;
    public javax.swing.JToggleButton multiply;
    public java.awt.TextArea out;
    public javax.swing.JToggleButton plus;
    private java.awt.TextField row1;
    private java.awt.TextField row2;
    private java.awt.Label rowt1;
    private java.awt.Label rowt2;
    // End of variables declaration//GEN-END:variables
}
