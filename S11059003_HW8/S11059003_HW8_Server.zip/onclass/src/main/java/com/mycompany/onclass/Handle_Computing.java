/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onclass;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.*;
/**
 *
 * @author USER
 */
public class Handle_Computing extends Thread {
    private Socket socket;
    private RunServer server;
    private static long id;
    
    public Handle_Computing(Socket socket, RunServer server) {
        this.socket = socket;
        this.server = server;
        Handle_Computing.id = RunServer.id;
    }
    
    public void run() {
        Scanner input = null;
        PrintWriter output = null;
        try {
            input = new Scanner(socket.getInputStream());
            output = new PrintWriter(socket.getOutputStream(), true);
            
            while(true) {
                id = input.nextLong();
                if(!(input.nextInt() == 2)) {
                    String first = null, second = null;
                    boolean is_correct_size;

                    id = input.nextLong();
                    int mode = input.nextInt();
                    if(mode == 0) {
                        server.getWindow().text.append("Client id = " + id + ", Matrix plus selected.\n");
                    }
                    else {
                        server.getWindow().text.append("Client id = " + id + ", Matrix multiply selected.\n");
                    }

                    is_correct_size = input.nextBoolean();
                    input.nextLine();       //clean buffer
                    OUTER:
                    if (is_correct_size) {
                        id = input.nextLong();
                        input.nextLine();   //clean buffer
                        int[] size = get_matrix_as_int(input.nextLine());
                        server.getWindow().text.append("Client id = " + id + ", Matrix sizes received.\n");
                        int count = 0; 

                        OUTER_1:
                        while(count < 2) {
                            id = input.nextLong();
                            switch (input.nextInt()) {
                                case 0 -> {
                                    input.nextLine();
                                    first = input.nextLine();
                                    server.getWindow().text.append("Client id = " + id + ", Client sent the first matrix.\n");
                                    count++;
                                }
                                case 1 -> {
                                    input.nextLine();
                                    second = input.nextLine();
                                    server.getWindow().text.append("Client id = " + id + ", Client sent the second matrix.\n");
                                    count++;
                                }
                                default -> {
                                    break OUTER_1;
                                }
                            }

                        }

                        if (!(first == null) && !(second == null)) {
                            if (mode == 0) {
                               output.println(plus(first, second));
                            } 
                            else {
                                output.println(multiply(first, second, size));
                            }
                        }
                    }
                    else {
                        server.getWindow().text.append("Client id = " + id + ", The sizes are not acceptable.\n");
                    }
                }
                else {
                    break;
                }
            }
            output.println("Client id = " + id + ", Client disconnected.\n");
            server.getWindow().text.append("Client id = " + id + ", Client disconnected.\n");
        }
        catch(IOException e) {
            Logger.getLogger(Handle_Computing.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    private static int[] get_matrix_as_int(String str) {
        int i;
        String[] buffer = str.substring(1, str.length() - 1).split(", ");
        int[] result = new int[buffer.length];
        for(i = 0; i < buffer.length; i++) {
            result[i] = Integer.parseInt(buffer[i]);
        }
        return result;
    }
    
    private static String plus(String first, String second) {
        int[] matrix1 = get_matrix_as_int(first);
        int[] matrix2 = get_matrix_as_int(second);
        int[] matrix = new int[matrix1.length];
        int i;
        
        for(i = 0; i < matrix.length; i++) {
            matrix[i] = matrix1[i] + matrix2[i];
        }
        return Arrays.toString(matrix);
    }
    
    private static String multiply(String first, String second, int[] size) {
        int[][] matrix1 = matrix_2d(first, size[0], size[1]);
        int[][] matrix2 = matrix_2d(second, size[2], size[3]);
        int[] result = new int[size[0]*size[3]];
        int i, j, k;
        int index = 0;
        
        for(i = 0; i < size[0]; i++) {
            for(j = 0; j < size[3]; j++) {
                int sum = 0;
                for(k = 0; k < size[1]; k++) {
                    sum += matrix1[i][k] * matrix2[k][j];
                }
                result[index++] = sum;
            }
        }
        return Arrays.toString(result);
    }
    
    private static int[][] matrix_2d(String str, int row, int col) {
        int[] temp = get_matrix_as_int(str);
        int[][] result = new int[row][col];
        int index = 0;
        int i, j;
         for(i = 0; i < row; i++) {
            for(j = 0; j < col; j++) {
                result[i][j] = temp[index++];
            }
        }
        return result;
    }
}
